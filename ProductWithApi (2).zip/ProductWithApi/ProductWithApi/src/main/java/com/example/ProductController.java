package com.example;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/")
public class ProductController {

    @Autowired
    private ProductRepository repo;

    // Thymeleaf View Methods
    @GetMapping("")
    public String getAllProducts(@RequestParam(defaultValue = "0") int page, Model model) {
        Page<Product> products = repo.findAll(PageRequest.of(page, 5)); // 5 items per page
        model.addAttribute("products", products.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", products.getTotalPages());
        return "index";
    }

    @GetMapping("/create")
    public String create(Model model) {
        model.addAttribute("product", new Product());
        return "create-product";
    }

    @PostMapping("/create")
    public String createProduct(@ModelAttribute Product product) {
        repo.save(product);
        return "redirect:/";
    }

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        Product product = repo.findById(id).orElse(null);
        model.addAttribute("product", product);
        return "edit-product";
    }

    @PostMapping("/update/{id}")
    public String updateProduct(@PathVariable Long id, @ModelAttribute Product productDetails) {
        Product product = repo.findById(id).orElse(null);
        if (product != null) {
            product.setName(productDetails.getName());
            product.setPrice(productDetails.getPrice());
            product.setDescription(productDetails.getDescription());
            repo.save(product);
        }
        return "redirect:/";
    }

    @GetMapping("/delete/{id}")
    public String deleteProduct(@PathVariable Long id) {
        repo.deleteById(id);
        return "redirect:/";
    }

    // REST API Endpoints
    @RestController
    @RequestMapping("/api/products")
    static class ProductRestController {

        @Autowired
        private ProductRepository repo;

        @GetMapping
        public List<Product> getAllProducts(@RequestParam(defaultValue = "0") int page,
                                            @RequestParam(defaultValue = "5") int size) {
            return repo.findAll(PageRequest.of(page, size)).getContent();
        }

        @GetMapping("/{id}")
        public Product getProductById(@PathVariable Long id) {
            return repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
        }

        @PostMapping
        public Product createProduct(@RequestBody Product product) {
            return repo.save(product);
        }

        @PutMapping("/{id}")
        public Product updateProduct(@PathVariable Long id, @RequestBody Product productDetails) {
            Product product = repo.findById(id).orElseThrow(() -> new RuntimeException("Product not found with ID: " + id));
            product.setName(productDetails.getName());
            product.setPrice(productDetails.getPrice());
            product.setDescription(productDetails.getDescription());
            return repo.save(product);
        }

        @DeleteMapping("/{id}")
        public String deleteProduct(@PathVariable Long id) {
            repo.deleteById(id);
            return "Product with ID " + id + " deleted successfully";
        }
    }
}
